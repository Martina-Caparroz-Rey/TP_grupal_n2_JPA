package com.tp.jpa.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "domicilios")
public class Domicilio extends EntityId {

    private String nombreCalle;
    private String numeroCalle;

    // Getters y Setters
    public String getNombreCalle() { return nombreCalle; }
    public void setNombreCalle(String nombreCalle) { this.nombreCalle = nombreCalle; }

    public String getNumeroCalle() { return numeroCalle; }
    public void setNumeroCalle(String numeroCalle) { this.numeroCalle = numeroCalle; }
}