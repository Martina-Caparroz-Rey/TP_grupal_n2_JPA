package com.tp.jpa;

import com.tp.jpa.entities.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.Date;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            Date ahora = new Date();


            Usuario admin = new Usuario();
            admin.setUsuario("admin");
            admin.setClave("123456");
            admin.setNombre("Juan");
            admin.setApellido("Pérez");
            em.persist(admin);


            PuntoVenta pv = new PuntoVenta();
            pv.setNumero(1);
            pv.setDescripcion("Punto de Venta Central");
            pv.setTipoEmision("Electrónica");
            pv.setDomicilioComercial("Av. Siempreviva 742");
            pv.setFechaAlta(ahora);
            pv.setFechaModificacion(ahora);
            pv.setUsuarioCarga(admin);
            pv.setUsuarioModificacion(admin);
            em.persist(pv);



            Rubro rubroTech = new Rubro();
            rubroTech.setCodigo(100);
            rubroTech.setDenominacion("Tecnología");
            rubroTech.setFechaAlta(ahora);
            rubroTech.setFechaModificacion(ahora);
            rubroTech.setUsuarioCarga(admin);
            rubroTech.setUsuarioModificacion(admin);
            em.persist(rubroTech);


            Marca marcaLogi = new Marca();
            marcaLogi.setCodigo(200);
            marcaLogi.setDenominacion("Logitech");
            marcaLogi.setFechaAlta(ahora);
            marcaLogi.setFechaModificacion(ahora);
            marcaLogi.setUsuarioCarga(admin);
            marcaLogi.setUsuarioModificacion(admin);
            em.persist(marcaLogi);


            CondicionIva condIva = new CondicionIva();
            condIva.setCodigoAfip(1);
            condIva.setDenominacion("IVA Responsable Inscripto");
            condIva.setFechaAlta(ahora);
            condIva.setFechaModificacion(ahora);
            condIva.setUsuarioCarga(admin);
            condIva.setUsuarioModificacion(admin);
            em.persist(condIva);



            TipoMoneda monedaARS = new TipoMoneda();
            monedaARS.setCodigoAfip("PES");
            monedaARS.setDenominacion("Pesos Argentinos");
            monedaARS.setSimbolo("$");
            monedaARS.setFechaAlta(ahora);
            monedaARS.setFechaModificacion(ahora);
            monedaARS.setUsuarioCarga(admin);
            monedaARS.setUsuarioModificacion(admin);
            em.persist(monedaARS);



            Contacto contactoCli = new Contacto();
            contactoCli.setEmail("cliente@empresa.com");
            contactoCli.setTelefono("011-4444-5555");
            contactoCli.setCelular("11-9999-8888");

            Domicilio domicilioCli = new Domicilio();
            domicilioCli.setNombreCalle("Av. Corrientes");
            domicilioCli.setNumeroCalle("1234");

            Cliente cliente = new Cliente();
            cliente.setCuitCuil("30-12345678-9");
            cliente.setDenominacion("Empresa Cliente S.A.");
            cliente.setContacto(contactoCli);
            cliente.setDomicilio(domicilioCli);
            cliente.setFechaAlta(ahora);
            cliente.setFechaModificacion(ahora);
            cliente.setUsuarioCarga(admin);
            cliente.setUsuarioModificacion(admin);
            em.persist(cliente);


            Articulo mouse = new Articulo();
            mouse.setCodigo("ART-001");
            mouse.setDenominacion("Mouse Inalámbrico MX Master 3");
            mouse.setRubro(rubroTech);
            mouse.setMarca(marcaLogi);
            mouse.setFechaAlta(ahora);
            mouse.setFechaModificacion(ahora);
            mouse.setUsuarioCarga(admin);
            mouse.setUsuarioModificacion(admin);
            em.persist(mouse);



            ListaPrecio listaGral = new ListaPrecio();
            listaGral.setCodigo("LP-01");
            listaGral.setDenominacion("Lista General Minorista");
            listaGral.setFechaAlta(ahora);
            listaGral.setFechaModificacion(ahora);
            listaGral.setUsuarioCarga(admin);
            listaGral.setUsuarioModificacion(admin);
            em.persist(listaGral);


            ListaPrecioArticulo lpArticulo = new ListaPrecioArticulo();
            lpArticulo.setListaPrecio(listaGral);
            lpArticulo.setArticulo(mouse);
            lpArticulo.setPrecioVenta(15000.0);
            lpArticulo.setFechaAlta(ahora);
            lpArticulo.setFechaModificacion(ahora);
            lpArticulo.setUsuarioCarga(admin);
            lpArticulo.setUsuarioModificacion(admin);
            em.persist(lpArticulo);



            FacturaVenta facturaVenta = new FacturaVenta();
            facturaVenta.setNumero(1001L);
            facturaVenta.setFechaEmision(ahora);
            facturaVenta.setPuntoVenta(pv);
            facturaVenta.setCliente(cliente);            // Asignación Cliente
            facturaVenta.setCondicionIva(condIva);        // Asignación CondicionIva
            facturaVenta.setTipoMoneda(monedaARS);        // Asignación TipoMoned
            facturaVenta.setEstado("EMITIDA");
            facturaVenta.setImporteTotal(30000.0);
            facturaVenta.setImporteCobrado(30000.0);
            facturaVenta.setImporteSaldo(0.0);
            facturaVenta.setFechaAlta(ahora);
            facturaVenta.setFechaModificacion(ahora);
            facturaVenta.setUsuarioCarga(admin);
            facturaVenta.setUsuarioModificacion(admin);


            FacturaVentaDetalle detalle1 = new FacturaVentaDetalle();
            detalle1.setListaPrecioArticulo(lpArticulo);
            detalle1.setDescripcion("Mouse Inalámbrico MX Master 3");
            detalle1.setCantidad(2);
            detalle1.setPrecioUnitario(15000.0);
            detalle1.setImporteSubtotal(30000.0);

            // Asociar bidireccionalmente el detalle
            facturaVenta.addDetalle(detalle1);

        
            em.persist(facturaVenta);

            em.getTransaction().commit();


        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}