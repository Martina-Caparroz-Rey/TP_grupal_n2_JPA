package com.tp.jpa.entities;

import jakarta.persistence.*;
import java.io.Serializable;

@MappedSuperclass
public abstract class EntityId implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}